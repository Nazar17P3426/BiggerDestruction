###########
DEL826DRIVE
###########
Your PC will die after this
Trojan: Noskid
Type: Destructive, i guess
it also overwrites your MBR to Make your PC unbootable
If you reboot, Then your MBR died.
!!DONT RUN ON REAL MACHINE AND RUN ONLY IN VM!!